package com.example.userinterfacewithcalendar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AlertDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Switch;

public class MainActivity extends AppCompatActivity {

    private EditText editTextName;
    private Switch switchExample;
    private CheckBox checkBoxExample;
    private CalendarView calendarView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editTextName = findViewById(R.id.editTextName);
        switchExample = findViewById(R.id.switchExample);
        checkBoxExample = findViewById(R.id.checkBoxExample);
        calendarView = findViewById(R.id.calendarView);

        // Установка даты на 24 апреля 2025 года
        calendarView.setDate(1682294400000L); // Время в миллисекундах для 24 апреля 2025 года

        Button buttonSubmit = findViewById(R.id.buttonSubmit);

        buttonSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = editTextName.getText().toString();
                boolean isSwitchOn = switchExample.isChecked();
                boolean isCheckBoxChecked = checkBoxExample.isChecked();
                long selectedDate = calendarView.getDate();

                String message = "Имя: " + name +
                        "\nУведомления включены: " + isSwitchOn +
                        "\nСогласие с условиями: " + isCheckBoxChecked +
                        "\nВыбранная дата: " + selectedDate;

                new AlertDialog.Builder(MainActivity.this)
                        .setTitle("Информация")
                        .setMessage(message)
                        .setPositiveButton("OK", null)
                        .show();
            }
        });
    }
}